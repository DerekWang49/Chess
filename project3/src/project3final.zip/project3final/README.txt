Project 3: Derek Wang, wan00923@umn.edu
To run, navigate to the directories containing ArrayList.java and LinkedList.java. They can be run separately. As of now,
the isSorted instance variable, merge method, rotate method, and sort method are not fully functional in ArrayList.java.
In LinkedList.java, only both add methods, clear, and get methods are functional.
"I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course
policies in the ’Academic Integrity - Course Policy’ section of the course
syllabus.”