Project 4: Derek Wang, wan00923@umn.edu
Ensure that Cell.java, Main.java, Minefield.java, NGen.java, Q1Gen.java, QGen.java, Stack1Gen.java, and StackGen.java
are in the same module.
"I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course
policies in the ’Academic Integrity - Course Policy’ section of the course
syllabus.”